<?php if ( !function_exists('dynamic_sidebar')
    || !dynamic_sidebar('blog') ) : ?>
	
<?php endif; ?>